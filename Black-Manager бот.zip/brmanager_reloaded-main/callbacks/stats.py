from aiogram import Router,Bot,F
from aiogram. fsm. context import FSMContext
from aiogram.types import Message,CallbackQuery,ReplyKeyboardRemove
from keyboards.builder import *
from handlers.queries import *
from aiogram.fsm.state import StatesGroup,State
from aiogram.types.chat import Chat

from handlers.queries import *
from data.positions import *
#from utils.states import 
import logging

from datetime import datetime
from datetime import timedelta
import pytz

all_data=[]
moscow_tz = pytz.timezone('Europe/Moscow')
time = datetime.now(moscow_tz).strftime("%d/%m/%Y %H:%M:%S")
router = Router()

@router.callback_query(lambda call: call.data=='stats_bot')
async def user_stats_bot(call:CallbackQuery):
    
    if await user_exists(call.from_user.id):
        try:
            await call.message.edit_reply_markup(reply_markup=None)
            server = await get_user_server(call.from_user.id)
            nickname = await get_nickname(call.from_user.id)
            stats = await get_user_stats(nickname,server)
            neaktiv = await get_user_neaktiv(call.from_user.id)
            current_month = datetime.now().month
            count_neaktiv = await get_user_neaktiv_info(call.from_user.id,current_month)
            days_with_neaktiv = await get_neaktiv_days(call.from_user.id)
            stats_message=(
                "👱‍♂️ Моя статистика\n\n"
                "<b>Основная информация:</b>\n\n"
                f"— Текущая должность: {stats[3]}\n"
                f"— Был создан пользователем: {stats[2]}\n"
                f"— Был добавлен в: {stats[5]}\n"
                f"— Мой отдел: {stats[6]}\n"
                f"— Последнее повышения: {stats[4]}\n"
                #f"— Дни на должности:\n\n"
                "<b>😴Твой текущий/последний неактив:</b>\n\n"
                f"— Дата неактива: {neaktiv[5]}\n"
                f"— Причина неактива: {neaktiv[8]}\n"
                f"— Кол-во неактивов в месяце: {count_neaktiv}\n"
                f"— Кол-во дней проведенных в неактиве: {days_with_neaktiv}"

            )
            await call.message.answer(text=stats_message,reply_markup=neaktiv_manage())
            logging.info(f'{call.from_user.id} - Просмотрел личную статистику(BOT) - {time}MSK')
        except Exception as e:
            await call.message.answer(text=f"😔 Произошла ошибка: {e}")
            logging.info(f'{call.from_user.id} - Произошла ошибка при просмотре личной статистики: {e},stats.py - {time}MSK')

    else:
        await call.answer(text="Недоступно.",show_alert=True)

@router.callback_query(lambda call: call.data=='stats_game')
async def user_stats_game(call:CallbackQuery):  
    department = await get_user_department(call.from_user.id)
    if department == 'Лидеры':
            await call.answer(text="Данная функция доступна только Администраторам и Агентам Поддержки.",show_alert=True)
            return  
    else:
        await call.message.edit_text(text="Выберите день за который желаете проверить вашу игровую статистику.",reply_markup=select_day())

@router.callback_query(lambda call: call.data.startswith("stats_game_"))
async def handle_game_stats(call:CallbackQuery,):
    if await user_exists(call.from_user.id):
        try:
            all_data.clear()
            #
            day_param = call.data.split('_')[2]
            current_datetime = datetime.now()
            department = await get_user_department(call.from_user.id)
            if day_param == 'week':
                start_of_week = current_datetime - timedelta(days=current_datetime.weekday())

                end_of_week = start_of_week + timedelta(days=5)

                min_date = start_of_week.strftime("%Y-%m-%d")
                end_date = end_of_week.strftime("%Y-%m-%d")

            elif day_param == 'month':
                start_of_month = datetime(current_datetime.year, current_datetime.month, 1)

                last_day_of_month = (datetime(current_datetime.year, current_datetime.month + 1, 1) - timedelta(days=1)).replace(hour=23, minute=59, second=59)

                min_date = start_of_month.strftime("%Y-%m-%d")
                end_date = last_day_of_month.strftime("%Y-%m-%d")

            else:
                day = int(day_param)
                
                target_date = datetime.now() - timedelta(days=day)
                min_date = target_date.strftime("%Y-%m-%d")
                end_date = min_date
            
            #min_date = "2024-01-08"
            #end_date = "2024-01-08"
            nickname = await get_nickname(call.from_user.id)
            server = await get_user_server(call.from_user.id)
            sessionid = await get_sessiond(server)

            if nickname:
                await call.message.edit_reply_markup(reply_markup=None)
                await call.message.answer(text="Идет сбор информации, пожалуйста не взаимодействуйте с ботом.",)
                session = requests.Session()
                cookie = {'sessionid': sessionid}
                session.cookies.update(cookie)
                total_requests_count = 0
                category_id = ''
                params = {
                    'category_id__exact': category_id,
                    'player_name__exact': '',
                    'player_id__exact': '',
                    'player_ip__exact': '',
                    'transaction_amount__exact': '',
                    'balance_after__exact': '',
                    'transaction_desc__ilike': '',
                    'time__gte': f'{min_date}T00:00:00',
                    'time__lte': f'{end_date}T23:59:59',
                    'order_by': 'time',
                    'offset': 0,
                    'auto': False
                }

                if server == 'SPB':
                    url = f'https://logs.blackrussia.online/gslogs/24/api/list-game-logs/'
                elif server == 'BLACK':
                    url = f'https://logs.blackrussia.online/gslogs/10/api/list-game-logs/'
                elif server == 'ROSTOV':
                    url = f'https://logs.blackrussia.online/gslogs/29/api/list-game-logs/'
                elif server == 'ANAPA':
                    url = f'https://logs.blackrussia.online/gslogs/30/api/list-game-logs/'

                params['player_name__exact'] = nickname
                offset = 0
                total_count_report = 0
                connection_times = []
                disconnect_times = []

                while True:
                    params['offset'] = offset
                    response = session.get(url, params=params)

                    if response.status_code == 200:
                        data = response.json()
                        count = len(data)

                        if count == 0:
                            #await call.message.answer(text=f"Никаких данных не найдено для администратора {nickname} за указанный период {min_date}/{min_date}.")
                            break

                        total_count_report += count
                        total_requests_count += count

                        offset += count
                        all_data.extend(data)

                        for item in data:
                            event_time = datetime.fromisoformat(item['time'])
                            if 'Пользователь подключился' in item['transaction_desc']:
                                connection_times.append(event_time)
                            elif 'Пользователь отключился' in item['transaction_desc']:
                                disconnect_times.append(event_time)

                    else:
                        await call.message.answer(text=f"Ошибка при выполнении запроса: {response.status_code}")
                        break
                    
                if total_requests_count == 0:
                    await call.message.answer(text=f"Никаких данных не найдено для администратора {nickname} за указанный период {min_date}/{min_date}.")
                    return
                        
                report = sum(1 for item in all_data if 'transaction_desc' in item and 'Жалоба от' in item['transaction_desc'])
                ask = sum(1 for item in all_data if 'transaction_desc' in item and 'Вопрос' in item['transaction_desc'])
                events = sum(1 for item in all_data if 'transaction_desc' in item and 'Создал мероприятие' in item['transaction_desc'])
                jails = sum(1 for item in all_data if 'transaction_desc' in item and 'Посадил в деморган игрока' in item['transaction_desc'])
                mutes = sum(1 for item in all_data if 'transaction_desc' in item and 'Выдал мут игроку' in item['transaction_desc'])
                warns = sum(1 for item in all_data if 'transaction_desc' in item and 'Выдал предупреждение' in item['transaction_desc'])
                bans = sum(1 for item in all_data if 'transaction_desc' in item and 'Заблокировал игрока' in item['transaction_desc'])
                kicks = sum(1 for item in all_data if 'transaction_desc' in item and 'Кикнул' in item['transaction_desc'])
                p_bans = sum(1 for item in all_data if 'transaction_desc' in item and 'Навсегда заблокировал' in item['transaction_desc'])
                ps_bans = sum(1 for item in all_data if 'transaction_desc' in item and 'Навсегда тихо заблокировал' in item['transaction_desc'])
            
                total_bans = bans + p_bans + ps_bans

                
                
                if not connection_times or not disconnect_times:
                    rounded_total_session_time  = 0
                else:
                    connection_labels = [{"time": time, "label": "Пользователь подключился"} for time in connection_times]
                    disconnect_labels = [{"time": time, "label": "Пользователь отключился"} for time in disconnect_times]

                    all_labeled_times = connection_labels + disconnect_labels

                    all_labeled_times.sort(key=lambda x: x["time"], reverse=True)

                    session_durations = []
                    if all_labeled_times[0]["label"] == "Пользователь подключился" and all_labeled_times[-1]["label"] == "Пользователь подключился":
                        pass
                    if all_labeled_times[0]["label"] == "Пользователь подключился":
                        all_labeled_times = all_labeled_times[1:]
                    if all_labeled_times[0]["label"] == "Пользователь подключился" and all_labeled_times[-1]["label"] == "Пользователь отключился":
                        all_labeled_times = all_labeled_times[1:-1]
                    if all_labeled_times[-1]["label"] == "Пользователь отключился":
                        all_labeled_times = all_labeled_times[:-1]

                    session_durations = []
                    for i in range(0, len(all_labeled_times), 2):
                        connection_time = all_labeled_times[i]["time"]
                        disconnection_time = all_labeled_times[i + 1]["time"]
                        session_duration = disconnection_time - connection_time
                        session_durations.append(round(abs(session_duration.total_seconds() / 60)))

                    total_session_time = sum(session_durations)
                    
                    current_time = datetime.now().strftime("%d-%m-%Y/%H:%M:%S")

                
                    stats_message = "<b> ℹ️ Ваша игровая статистика</b>\n\n"
                    stats_message += f"┃ Дата норматива: {min_date}/{end_date}\n\n"
                    stats_message += f"┃ Онлайн: {total_session_time} минут(-ы)\n"

                    if department == 'Администрация':
                            stats_message += f"┃ Банов: {total_bans}\n"
                            stats_message += f"┃ Киков: {kicks}\n"
                            stats_message += f"┃ Мутов: {mutes}\n"
                            stats_message += f"┃ Варнов: {warns}\n"
                            stats_message += f"┃ Ответов: {report}\n"
                            stats_message += f"┃ Мероприятий: {events}\n"
                            stats_message += f"┃ Джаилов: {jails}\n\n"
                            
                        
                    elif department == 'АП':
                            stats_message += f"┃ Ответов: {ask}\n"
                    
                    stats_message += f"┃ <b>Общее количество действий за указанный промежуток: {total_count_report}</b>\n\n"
                    stats_message += f"┃ P.S Ваш онлайн может отображаться некорректно.\n"
                    stats_message += f"┃ Локальное время сервера: {current_time}"
                    await call.message.answer(text=stats_message)
                    logging.info(f'{call.from_user.id} - Просмотрел личную статистику(Game),Параметры: {min_date}/{end_date} - {time}MSK')
        except Exception as e:
            await call.message.answer(text=f"😔 Произошла ошибка: {e}")   
            logging.info(f'{call.from_user.id} - Произошла ошибка при получение данных с логов(my_stats_game): {e},stats.py - {time}MSK')
    else:
        await call.answer(text="Недоступно.",show_alert=True)
        

    
